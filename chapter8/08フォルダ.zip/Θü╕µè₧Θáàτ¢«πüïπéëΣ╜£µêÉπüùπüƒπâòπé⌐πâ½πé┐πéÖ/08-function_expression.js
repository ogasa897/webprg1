const sayHello = function(){
    console.log('こんにちは');
}


sayHello();