function hello(name){
    console.log(`こんにちは${name}さん`)
}

hello('Alice');
hello();