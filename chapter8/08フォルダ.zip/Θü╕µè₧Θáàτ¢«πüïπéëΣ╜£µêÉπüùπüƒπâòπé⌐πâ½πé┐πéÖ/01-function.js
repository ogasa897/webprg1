function hello(){
    console.log('こんにちは');
}

hello();
hello();