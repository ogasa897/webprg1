function sum(a, b){
    const result = a + b;
    return result;
}

const x = sum(3, 5);
console.log(x);

const y = sum(10, 20);
console.log(y);