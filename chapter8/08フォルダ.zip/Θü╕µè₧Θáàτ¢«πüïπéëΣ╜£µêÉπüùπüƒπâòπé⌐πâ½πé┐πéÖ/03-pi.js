function pi(){
    return 3.14;
}

const a = pi();
console.log(a);