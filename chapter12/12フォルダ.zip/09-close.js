const newWindow = open('https://example.com/');

newWindow.close();