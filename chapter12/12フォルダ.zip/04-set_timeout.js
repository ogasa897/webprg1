function delayTask(){
    console.log('1秒後に実行する');
}

setTimeout(delayTask, 1000);