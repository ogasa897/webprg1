location.relodad();
location.href = 'http://www.google.co.jp/';