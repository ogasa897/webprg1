function delayTask(){
    console.log('1秒毎に繰り返し実行する');
}
setInterval(delayTask, 1000);