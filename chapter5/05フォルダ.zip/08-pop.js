const alphabet = ['a','b','c'];
const last = alphabet.pop();
console.log(last);

console.log(alphabet);