const interests = ['読書','料理','キャンプ'];
const element0 = interests[0];
console.log(element0);