const interests = ['読書','料理','キャンプ'];
interests.push('散歩');
console.log(interests);