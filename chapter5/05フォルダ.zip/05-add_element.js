const interests = ['読書','料理','キャンプ'];
interests[3] = '散歩';
console.log(interests);