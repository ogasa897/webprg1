const profile = document.querySelector('.profile');
profile.dataset.id = 999;
profile.dataset.userName = 'new zaru';
console.log(profile);