const element = document.querySelector('p');
element.classList.add('warning');