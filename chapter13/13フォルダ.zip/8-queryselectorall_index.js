const elements = document.querySelectorAll('.sample');
console.log(elements[0]);