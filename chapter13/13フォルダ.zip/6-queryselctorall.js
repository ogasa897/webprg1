const elements = document.querySelectorAll('.sample');
console.log(elements.length);