const p = document.querySelector('p');
p.textContent = '変更します';