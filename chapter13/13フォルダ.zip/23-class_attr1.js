const element = document.querySelector('p');
element.classList.remove('normal');