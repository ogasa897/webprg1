const element = document.querySelector('p');
element.classList.replace('normal', 'warning');