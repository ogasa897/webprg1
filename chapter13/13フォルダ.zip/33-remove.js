const firstElement = document.querySelector('.first');
firstElement.remove();