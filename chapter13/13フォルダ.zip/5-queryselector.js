const element = document.querySelector('.sample');
console.log(element);