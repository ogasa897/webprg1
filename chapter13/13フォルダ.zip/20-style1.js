const p = document.querySelector('p');
p.style.fontSize = '36px';