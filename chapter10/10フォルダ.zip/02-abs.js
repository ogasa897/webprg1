console.log(Math.abs(-10));
console.log(Math.abs(10));