console.log(Math.round(1.4));
console.log(Math.round(1.5));
console.log(Math.floor(10.3));
console.log(Math.ceil(10.3));