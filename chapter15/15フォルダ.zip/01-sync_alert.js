function syncAlert() {
    alert('アラートを表示');
    console.log('ログを出力');
}
syncAlert();