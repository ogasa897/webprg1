const person = {
    name: 'アリス',
    age: 20,
    interests: ['読書','料理'],
    greet: function(){console.log('こんにちは');}
}